package com.kh.board.medel.service;

import java.sql.Connection;
import java.util.List;

import com.kh.board.medel.dao.BoardDAO;
import com.kh.board.medel.dto.BoardDTO;
import com.kh.board.medel.vo.Board;
import com.kh.common.JDBCTemplate;
import com.kh.statement.model.dao.MemberDao;
import com.kh.statement.model.vo.Member;

public class BoardService {
	private Connection conn = null;
	
	public BoardService() {
		this.conn = JDBCTemplate.getConnection();
	}
	
	public int insertBoard(BoardDTO bd) {
		// 내가 입력한 값을 가지고
		// Board테이블에 한 행 INSERT해줘~
		int result = 0;
		
		// 1. 값의 유효성 검증
		if("".equals(bd.getBoardTitle().trim())) {
			return result;
		}
		// 제목 : 안녕하세요, 내용 : 반갑습니다, 아이디 : admin
		// 2. 인증 / 인가
		Member member = new MemberDao().findById(conn, bd.getBoardWriter());
		
		if(member != null) {
			int userNo = member.getUserNo();
			Board board = new Board(0, bd.getBoardTitle(), bd.getBoardContent(), String.valueOf(userNo), null, null);
			result = new BoardDAO().insertBoard(conn, board);
		}
		
		if(result > 0) {
			JDBCTemplate.commit(conn);
		}
		
		JDBCTemplate.close(conn);
		
		return result;
	}
	
	public List<Board> selectBoardList() {
		
		List<Board> boards = new BoardDAO().selectBoardList(conn);
		new BoardDAO().outputHTML(conn);
		JDBCTemplate.close(conn);
		
		return boards;
	}
	
	public Board selectBoard(int boardNo) {
		
		// 아 이거 보드 넘버 시퀀스 가지고 만든건데...
		// 직접 한땀한땀 만든게아니라 시퀀스로 만든건데...
		// 1부터 시작인데 이상한 숫자 0이하값 들어오면 갈 필요없는데...
		// DB가면 돈드는데... 아까운데..
		Board board = null;
				
		
		if(boardNo > 0) {
			board = new BoardDAO().selectBoard(conn, boardNo);
		}
		
		JDBCTemplate.close(conn);
		
		return board;
	}

	public int deleteBoard(int boardNo) {
		
		int result = 0;
		
		if(boardNo > 0) {
			result = new BoardDAO().deleteBoard(conn, boardNo);
		}
		
		JDBCTemplate.close(conn);
		
		return result;
	}
}
